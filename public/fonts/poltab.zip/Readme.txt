NOTE: This demo font is for PERSONAL USE ONLY!
Be very careful and take the time to read any and all documentation before deciding
to use a font commercially. Ignorance is not an excuse for breaking the law.
By installing or using this font, you are hereby agree
to this Product Usage Agreement:
1. This font is ONLY FOR PERSONAL USE
2. NO COMMERCIAL USE ALLOWED
3. You are REQUIRES A LICENSE for PROMOTIONAL or COMMERCIAL USE
4. CONTACT ME before any Promotional or Commercial Use
5. Using this font for commercial purposes/interests, whatever the form
WITHOUT PERMISSION or WITHOUT PURCHASING A font LICENSE first from me, as the Creator
and/or the Font Copyright Holder, a LICENSE RENEWAL fee will be charged
or 100 times the price of the Standard License price, or in accordance with the provisions
has been regulated in the Law of the Republic of Indonesia Number 28 of 2014 concerning Copyright

If you want to purchase this font : 

If you need an extended license or corporate license, please visit us at : https://graphicted.com/

